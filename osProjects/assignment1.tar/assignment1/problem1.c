#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <sys/wait.h>

int main(int argc, char *argv[])
{

    int childOne = fork();
    if (childOne == 0)
    {
        execvp(argv[1], argv + 1);
        exit(-1);
    }

    waitpid(childOne, NULL, 0);
    printf("++++\n");

    return 0;
}
