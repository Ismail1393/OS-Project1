#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <fcntl.h>

void extractCommands(char *argv[], int argc, char *commandOne[], char *commandTwo[])
{

    int i = 1;
    while (strcmp(argv[i], "|") != 0 && i < argc)
    {
        commandOne[i - 1] = argv[i];
        i++;
    }

    commandOne[i - 1] = NULL;

    int j = 0;
    i++;
    while (i < argc)
    {
        commandTwo[j] = argv[i];
        i++;
        j++;
    }

    commandTwo[j] = NULL;
}

int main(int argc, char *argv[])
{

    char *commandOne[128];
    char *commandTwo[128];

    extractCommands(argv, argc, commandOne, commandTwo);

    int fileDescriptor[2];
    pipe(fileDescriptor);

    int childOne = fork();

    if (childOne == 0)
    {
        dup2(fileDescriptor[1], STDOUT_FILENO);
        close(fileDescriptor[0]);
        close(fileDescriptor[1]);
        execvp(commandOne[0], commandOne);
    }

    int childTwo = fork();
    if (childTwo == 0)
    {
        dup2(fileDescriptor[0], STDIN_FILENO);
        close(fileDescriptor[0]);
        close(fileDescriptor[1]);
        execvp(commandTwo[0], commandTwo);
    }

    close(fileDescriptor[0]);
    close(fileDescriptor[1]);

    waitpid(childOne, NULL, 0);
    waitpid(childTwo, NULL, 0);

    printf("++++\n");

    return 0;
}
