## To compile and run use either of the following commands:

1.  gcc -o rwmain main.c -lpthread && ./rwmain
2.  make && ./rwmain

## Scenarios

Add required senarios to test the program, the file comes with default senarios.
