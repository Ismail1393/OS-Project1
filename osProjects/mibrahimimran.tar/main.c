#include "readerwriter.c"

int main()
{
    init(readerLock, 1);
    init(writerLock, 1);
    init(queueLock, 1);

    Thread threads[10000];
    int readerID = 0, writerID = 0, i = 0;
    FILE *file = fopen("scenarios.txt", "r");
    char readerOrWriter;
    if (file)
    {
        while (fscanf(file, "%c", &readerOrWriter) != EOF)
        {
            if (readerOrWriter == 'r')
            {
                int *id = createArgs(readerID++);
                threads[i++] = createThread(reader, id);
            }
            else if (readerOrWriter == 'w')
            {
                int *id = createArgs(writerID++);
                threads[i++] = createThread(writer, id);
            }
        }
        fclose(file);
        joinThreads(threads, i);
    }
    else
        printf("Scenario file is not existing...\n");

    return 0;
}