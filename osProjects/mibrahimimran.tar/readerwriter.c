#include "thread.c"

Semaphore readerLock;
Semaphore writerLock;
Semaphore queueLock;

int readersCount = 0;

void reading_writing()
{
    int i, j;
    int x = 0, T = rand() % 10000;
    for (i = 0; i < T; i++)
        for (j = 0; j < T; j++)
            x = i * j;
    (void)x;
}

void *writer(void *args)
{
    int writerID = ((int *)args)[0];
    sem_wait(&queueLock);
    sem_wait(&writerLock);
    sem_post(&queueLock);
    printf("\033[0;31m[%d] is writing...\033[0m\n", writerID);
    reading_writing();
    sem_post(&writerLock);

    return NULL;
}

void *reader(void *args)
{
    int readerID = ((int *)args)[0];
    sem_wait(&queueLock);
    sem_wait(&readerLock);
    readersCount++;

    if (readersCount == 1)
    {
        sem_wait(&writerLock);
    }

    sem_post(&readerLock);
    sem_post(&queueLock);

    printf("\033[0;32m[%d] is reading...\033[0m\n", readerID);
    reading_writing();

    sem_wait(&readerLock);

    readersCount--;

    if (readersCount == 0)
    {
        sem_post(&writerLock);
    }

    sem_post(&readerLock);
    return NULL;
}